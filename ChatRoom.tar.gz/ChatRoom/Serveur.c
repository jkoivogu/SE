/*******************CODE SERVEUR ********************************/
                                   

#include <stdio.h>       
#include <stdlib.h>       
#include <sys/socket.h>        //pour les sockets
#include <sys/types.h>       
#include <string.h>        //pour les operations de chaine
#include <netinet/in.h>        //Internet Protocol sockaddr_in familiale définie ici
#include <pthread.h>        // pour les threads
#include <arpa/inet.h>        // pour la fonction de inet_ntoa ()
#include <unistd.h>        //Constante NULL définie 
#include <signal.h>        //pour le signal ctrl + c

#define BACKLOG 100        // connections  dans la file d'attente (queue)
#define MAXDATALEN 256         //la taille maximale des messages a envoyer
#define PORT 2012        //numero de port par defaut

/*Remarque:    pour le moment  L'argument de port est facultatif. Si aucun port n'est specifie,
 *          Le serveur utilise la valeur par défaut donnee par PORT.*/


    struct Node                    /*structure pour gerer tous les clients*/
        {
            int port;
        	char username[10];
            struct Node *next;
        };

    typedef struct Node *ptrtonode;
    typedef ptrtonode head;
    typedef ptrtonode addr;

    void sendtoall(char *,int new_fd);    /*envoyer le message a tous les clients connectes*/
    void Quitall( );            /*envoyer msg a tous les clients si le serveur s'arrete*/
    head MakeEmpty( head h );        /*vider la liste*/
    void Delete( int port, head h );    /*supprimer ces valeurs a la sortie (client)*/
    void Insert(int port,char*,head h,addr a);/*insertion nouveau client */
    void DeleteList( head h );        /*vider la list*/
    void Display( const head h );        /*enumerer tous les clients connectes*/
    void *Quitproc( );             /*gestionnaire de signal*/
    void *server(void * arg);        /*instance de serveur pour chaque client connecte*/
    void zzz();


    char     username[10];        /*taille de nom d'utilisateur*/
    int sf2;
    head h;                /*variable du type tete de struct*/
    char    buffer[MAXDATALEN];
   
    /************************main starts *********************************************************/
int main(int argc, char *argv[]) {

    int       sockfd,new_fd;             /*variables pour socket*/
    int     portnum;            /*variable pour le numero de port si elle est fournie*/
    struct sockaddr_in     server_addr;    /*structure pour maintenir l'adresse de serveur */
    struct sockaddr_in     client_addr;    /*structure pour tenir l'adresse du client*/
    int     cli_size,z;            /*longueur de l'adresse */
    pthread_t     thr;            /*variable pour contenir l'ID du thread */
    int     yes=1;
     addr a;                    /*variable of type struct addr*/

    printf("\n\t*-*-*-*SERVEUR EN ROUTE*-*-*-*\n");
    /*=optional or default port argument=*/
  if( argc == 2 )   
      portnum = atoi(argv[1]);
  else
    portnum = PORT;  //si le numero du port n'est pas donne comme argument, on utilise le port par défaut
    printf("PORT NO.:\t%d\n",portnum);

    h = MakeEmpty( NULL );        //libere la liste
           

     /********les informations serveur*************************/
    server_addr.sin_family=AF_INET;        /* mettre la famille a l'Internet     */
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY); /* definir l'adresse IP */
    server_addr.sin_port=htons(portnum);
     printf("IP ADDRESS:\t%s\n",inet_ntoa(server_addr.sin_addr));

   /**********creation  socket*****************************/
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
   if(sockfd == -1){
    printf("server- socket() erreur");    //  erreur message
    exit(1);
    }else
    printf("socket\t\tcree.\n");

   if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes,sizeof(int)) == -1) {
    printf("setsockopt erreur");    //  erreur message
    exit(1);
   }else printf("port\t\t de reutilisation\n");

    /********** prise de liaison ***************************/
   if(bind(sockfd, (struct sockaddr *)&server_addr, sizeof(struct sockaddr))==-1){
        printf("liaison echoue\n");    //  erreur message
    exit(1);}
   else
    printf("succes\t\tde liaison.\n\n");
	printf("\t\tPRESS CTRL+z POUR VOIR LES CLIENTS EN LIGNE\n\n");
   /********* socket en mode d'ecoute ********************/
    listen(sockfd, BACKLOG);
    printf("attente de clients......\n");

   if (signal(SIGINT,(void *)Quitproc)==0)    //gestionnaire de signal
   if(signal(SIGTSTP, zzz)==0)            //gestionnaire de signal

   while(1){
           cli_size=sizeof(struct sockaddr_in); //cli_size est necessaire comme un argument pour pthread_create
           new_fd = accept(sockfd, (struct sockaddr *)&client_addr,&cli_size); //accepter la connexion du client
           a =h ;
       
        /*********connecter avec un speudo************************/
        bzero(username,10);       
        if(recv(new_fd,username,sizeof(username),0)>0);
           username[strlen(username)-1]=':';
           printf("\t%d->%s JOIN chatroom\n",new_fd,username);
           sprintf(buffer,"%s EST EN LIGNE\n",username);
           Insert( new_fd,username, h, a );            //insertion accepte du client dans la liste des clients
           a = a->next;

        /**avertir les clients sur les nouveaux clients connectes**/
           a = h ;
        do{
            a = a->next;
            sf2 = a->port;
        if(sf2!=new_fd)
        send(sf2,buffer ,sizeof(buffer),0);
        } while( a->next != NULL );

             printf("serveur obtient la connection de %s & %d\n\n",inet_ntoa(client_addr.sin_addr),new_fd); // debogage 

         struct Node args;                     //struct de passer plusieurs arguments a la fonction de serveur
            args.port=new_fd;
            strcpy(args.username,username);
           
          pthread_create(&thr,NULL,server,(void*)&args);     //creant fil (thread) pour chaque client connecte
          pthread_detach(thr);
      } /* fin while */

  DeleteList(h);                     //supprimer tous les clients lorsque le serveur ferme
  close(sockfd);

}/******************************************fin main***************************************************************/


    /*******Toutes les fonctions sont definies CI-DESSOUS*********/

/**********Fonction de serveur pour chaque client connecte******/

void *server(void * arguments){

  struct Node *args=arguments;

  char    buffer[MAXDATALEN],ubuf[50],uname[10];    /**(buffer) tampon des chaines que le serveur envoie**/ 
  char *strp;       
  char     *msg = (char *) malloc(MAXDATALEN);
  int     ts_fd,x,y;
  int     sfd,msglen;
 
  ts_fd = args->port;     /**socket variable passée comme argument**/
  strcpy(uname,args->username); 
  addr     a;
 
     /****envoyer la liste de clients en ligne****/
      a =h ;
             do{
        a = a->next;
        sprintf( ubuf," %s est en ligne\n",a->username );
        send(ts_fd,ubuf,strlen(ubuf),0);
        } while( a->next != NULL );
       

      /********demarrer le chat*******************/
   while(1){

        bzero(buffer,256);
        y=recv(ts_fd,buffer,MAXDATALEN,0);

     if (y==0)
      goto jmp;
                   
       /**si un client quit**/
     if ( strncmp( buffer, "quit", 4) == 0 ){
    jmp:    printf("%d ->%s est supprime de la liste du chat\n",ts_fd,uname);
        sprintf(buffer,"%s a quitte le chat\n",uname);
           
        addr a =  h ;
        do{
            a = a->next;
            sfd = a->port;
            if(sfd == ts_fd)
              Delete( sfd, h );
            if(sfd != ts_fd)
              send(sfd,buffer,MAXDATALEN,0);
          }while ( a->next != NULL );
       
            Display( h );
           
            close(ts_fd);
            free(msg);
           
           break;
         }

    /****envoyer un message a tous les clients****/
    printf("%s %s\n",uname,buffer);
    strcpy(msg,uname);
    x=strlen(msg);
    strp = msg;
    strp+= x;
    strcat(strp,buffer);
    msglen=strlen(msg);
         
       addr a = h ;
    do{
            a = a->next;
            sfd = a->port;
    if(sfd != ts_fd)
        send(sfd,msg,msglen,0);

    } while( a->next != NULL );

      Display( h );
      bzero(msg,MAXDATALEN);

    }//fin while
     return 0;

}// fin server


/*********vide et supprime la liste*******************/
head MakeEmpty( head h )
    {
    if( h != NULL )
        DeleteList( h );
        h = malloc( sizeof( struct Node ) );
    if( h == NULL )
        printf( "Out of memory!" );
        h->next = NULL;
    return h;
    }
/************supprimer la liste*********************/
void DeleteList( head h )
    {
    addr a, Tmp;
    a = h->next; 
    h->next = NULL;
        while( a != NULL )
        {
        Tmp = a->next;
        free( a );
        a = Tmp;
        }
    }
/******l'insertion de nouveaux clients a la liste******/
void Insert( int port,char *username, head h, addr a )
    {
    addr TmpCell;
    TmpCell = malloc( sizeof( struct Node ) );
        if( TmpCell == NULL )
        printf( "Plus de place!!!" );
    TmpCell->port = port;
    strcpy(TmpCell->username,username);
    TmpCell->next = a->next;
    a->next = TmpCell;
    }

/******afficher tous les clients de la liste************/
void Display( const head h )
    {
        addr a =h ;
        if( h->next == NULL )
    printf( "AUCUN CLIENT EN LIGNE\n" );

        else
        {
        do
        {
            a = a->next;
            printf( "%d->%s \t", a->port,a->username );
        } while( a->next != NULL );
        printf( "\n" );
        }
    }

/*******client supprime de la list si client quit*******/
void Delete( int port, head h ){
        addr a, TmpCell;
        a = h;
      while( a->next != NULL && a->next->port != port )
      a = a->next;
    if( a->next != NULL ){                     
    TmpCell = a->next;
    a->next = TmpCell->next; 
    free( TmpCell );
    }
 }

/********manipulation des signaux****************/
void *Quitproc(){    
    printf("\n\nARRET DU SERVEUR\n");
    Quitall( );
        exit(0);
  }

/**********a l'arret du serveur*****************/
void Quitall(){
   int sfd;
   addr a = h ;
   int i=0;
     if( h->next == NULL ) {
       printf( "......AU REVOIR.....\naucun client \n\n" );
    exit(0);
       } else {
       
             do{
           i++;
               a = a->next;
               sfd = a->port;
               send(sfd,"serveur hors service",21,0);
               } while( a->next != NULL );
           printf("%d clients fermes\n\n",i);            
      }
  }

void zzz(){
    printf("\rAFFICHAGE CLIENTS EN LIGNE\n\n");
    Display(h);
  }

/* ========================================================================================================= */
